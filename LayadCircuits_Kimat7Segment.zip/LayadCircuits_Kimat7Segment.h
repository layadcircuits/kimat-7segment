/***************************************************************************
 This is an Arduino library designed specifically to work with the Layad Circuits' Kimat - 7-segment module.
 
 This software is free provided that this notice is not removed and proper attribution 
 is accorded to Layad Circuits and its Author(s).
 Layad Circuits invests resources in producing free software. By purchasing Layad Circuits'
 products or utilizing its services, you support the continuing development of free software
 for all.
  
 Author(s): C.D.Malecdan for Layad Circuits Electronics Engineering
 Revision: 1.0 - 2017/07/09 - initial creation
 Layad Circuits Electronics Engineering Supplies and Services
 B314 Lopez Bldg., Session Rd. cor. Assumption Rd., Baguio City, Philippines
 www.layadcircuits.com
 general: info@layadcircuits.com
 sales: sales@layadcircuits.com
 +63-916-442-8565
 ***************************************************************************/
#ifndef LAYAD_CIRCUITS_KIMAT7SEGMENT_H
#define LAYAD_CIRCUITS_KIMAT7SEGMENT_H
#include "Arduino.h"

const byte MAXIMUM_DIGITS = 32;
const unsigned long BIT_INTERVAL_US = 2;

class LayadCircuits_Kimat7Segment
{
public:
	LayadCircuits_Kimat7Segment(uint8_t in,uint8_t clk,uint8_t lat,uint8_t clr);
    void begin();
	void dispRaw(byte * n, byte digits);
	void dispStr(char * str, byte digits);
	void dispNum(uint32_t num, byte digits);
	
private:
	uint8_t _inpin;
	uint8_t _clkpin;
	uint8_t _latpin;
	uint8_t _clrpin;
	const char ctable[50] = {
	  '0',
	  '1',
	  '2',
	  '3',
	  '4',
	  '5',
	  '6',
	  '7',
	  '8',
	  '9',
	  'A',
	  'B',
	  'C',
	  'D',
	  'E',
	  'F',
	  'G',
	  'H',
	  'I',
	  'J',
	  'K',
	  'L',
	  'M',
	  'N',
	  'O',
	  'P',
	  'Q',
	  'R',
	  'S',
	  'T',
	  'U',
	  'V',
	  'W',
	  'X',
	  'Y',
	  'Z',
	  '.',
	  '-',
	  '_',
	  '\'',
	  ' ',
	};

	//A,B,C,D,E,F,G,DP
	const byte btable[50] = {
	0b11111100, //'0',
	0b01100000, //'1',
	0b11011010, //'2',
	0b11110010, //'3',
	0b01100110, //'4',
	0b10110110, //'5',
	0b10111110, //'6',
	0b11100000, //'7',
	0b11111110, //'8',
	0b11110110, //'9',
	0b11101110, //'A',
	0b00111110, //'B',
	0b10011100, //'C',
	0b01111010, //'D',
	0b11110010, //'E',
	0b10001110, //'F',
	0b10111110, //'G',
	0b01101110, //'H',
	0b01100000, //'I',
	0b01111000, //'J',
	0b00000000, //'K',
	0b00011100, //'L',
	0b00000000, //'M',
	0b00101010, //'N',
	0b11111100, //'O',
	0b11001110, //'P',
	0b11110010, //'Q',
	0b00001010, //'R',
	0b10110110, //'S',
	0b00011110, //'T',
	0b01111100, //'U',
	0b00000000, //'V',
	0b00000000, //'W',
	0b00000000, //'X',
	0b01110110, //'Y',
	0b00000000, //'Z',
	0b00000001, //'.',
	0b00000010, //'-',
	0b00100000, //'_',
	0b01000000, //'\'',
	0b00000000, //' ',
	};


};
#endif