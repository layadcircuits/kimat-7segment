/***************************************************************************
 This is an Arduino library designed specifically to work with the Layad Circuits' Kimat - 7-segment module.
 
 This software is free provided that this notice is not removed and proper attribution 
 is accorded to Layad Circuits and its Author(s).
 Layad Circuits invests resources in producing free software. By purchasing Layad Circuits'
 products or utilizing its services, you support the continuing development of free software
 for all.
  
 Author(s): C.D.Malecdan for Layad Circuits Electronics Engineering
 Revision: 1.0 - 2017/07/09 - initial creation
 Layad Circuits Electronics Engineering Supplies and Services
 B314 Lopez Bldg., Session Rd. cor. Assumption Rd., Baguio City, Philippines
 www.layadcircuits.com
 general: info@layadcircuits.com
 sales: sales@layadcircuits.com
 +63-916-442-8565
 ***************************************************************************/
#include "Arduino.h"
#include "LayadCircuits_Kimat7Segment.h"

	
LayadCircuits_Kimat7Segment::LayadCircuits_Kimat7Segment(uint8_t in,uint8_t clk,uint8_t lat,uint8_t clr)
{
  _inpin = in;
  _clkpin = clk;
  _latpin = lat;
  _clrpin = clr;
}

void LayadCircuits_Kimat7Segment::begin(boolean config) {
  pinMode(_inpin,OUTPUT);
  pinMode(_clkpin,OUTPUT);
  pinMode(_latpin,OUTPUT);
  pinMode(_clrpin,OUTPUT);  
  isCommonAnode = config;
}

void LayadCircuits_Kimat7Segment::dispRaw(byte * n, byte digits)
{
    digitalWrite(_latpin,LOW);
    digitalWrite(_clrpin,LOW);
    delayMicroseconds(BIT_INTERVAL_US/2);
    digitalWrite(_clrpin,HIGH);

		
	
	
	for(byte d=0;d<digits;d++)
    {
      for(byte i=0;i<8;i++)
      {
          digitalWrite(_clkpin,HIGH);
          delayMicroseconds(BIT_INTERVAL_US/2);
		  
          if(isCommonAnode == CC) digitalWrite(_inpin,((n[digits-d]>>i)&0x01));
		  else digitalWrite(_inpin,!((n[digits-d]>>i)&0x01));
		  
          delayMicroseconds(BIT_INTERVAL_US/2);
          digitalWrite(_clkpin,LOW);
          delayMicroseconds(BIT_INTERVAL_US);
      }
    }
    digitalWrite(_clkpin,HIGH);
    delayMicroseconds(BIT_INTERVAL_US/2);
    digitalWrite(_clkpin,LOW);
    delayMicroseconds(BIT_INTERVAL_US); 
    digitalWrite(_latpin,HIGH);
}


void LayadCircuits_Kimat7Segment::dispStr(char * str, byte digits)
{
    byte temp_b[MAXIMUM_DIGITS+1];

    memset(temp_b,0,MAXIMUM_DIGITS+1);
    
    for(byte d=0;d<digits;d++)
    {
        for(byte i=0;i<50;i++)
        {
          if(str[d] == ctable[i])
          {
            temp_b[d+1] = btable[i]; 
            break;
          }
          
          if(i==99)
            {
              temp_b[d+1] = 0; // not found
              break;
            }
        }
    }
	
    dispRaw(temp_b,digits+1);
}

void LayadCircuits_Kimat7Segment::dispNum(uint32_t num, byte digits)
{
    char temp_c[MAXIMUM_DIGITS];
	memcpy(temp_c,' ',MAXIMUM_DIGITS);
	ltoa(num,temp_c,10);
    dispStr(temp_c,digits);
}













